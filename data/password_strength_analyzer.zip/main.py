from zxcvbn import zxcvbn

def analyze_password(password):
    result = zxcvbn(password)
    print(f"Password: {password}")
    print(f"Score (0-4): {result['score']}")
    print(f"Estimated Crack Time: {result['crack_times_display']['offline_fast_hashing_1e10_per_second']}")
    print("Suggestions:")
    for s in result['feedback']['suggestions']:
        print(f"- {s}")

def generate_wordlist(name, dob, pet):
    patterns = [name, dob, pet, name+dob, pet+dob]
    years = ['2024', '123', '321', '007']
    leetspeak = {'a': '@', 'e': '3', 'i': '1', 'o': '0', 's': '$'}
    final_words = set()

    for base in patterns:
        final_words.add(base)
        for year in years:
            final_words.add(base + year)
        leet = ''.join([leetspeak.get(c, c) for c in base])
        final_words.add(leet)

    with open("custom_wordlist.txt", "w") as f:
        for word in final_words:
            f.write(word + "\n")

    print(f"\n✅ Wordlist saved to custom_wordlist.txt ({len(final_words)} entries)")

if __name__ == "__main__":
    print("1. Password Strength Analyzer")
    print("2. Custom Wordlist Generator")
    choice = input("Select (1/2): ")

    if choice == '1':
        pwd = input("Enter a password to analyze: ")
        analyze_password(pwd)
    elif choice == '2':
        name = input("Name: ")
        dob = input("DOB (DDMMYYYY): ")
        pet = input("Pet Name: ")
        generate_wordlist(name, dob, pet)
    else:
        print("Invalid choice.")
