# 🔐 Password Strength Analyzer & Custom Wordlist Generator

This is a simple Python-based cybersecurity tool that lets you:

- ✅ Analyze the strength of a given password using the `zxcvbn` library.
- ✅ Generate a **custom wordlist** using personal information (name, DOB, pet name).
- ✅ Export the wordlist in `.txt` format – useful for ethical password testing and training.

---

## 🚀 Features

- Entropy-based password scoring (0 to 4)
- Crack time estimation (offline attacks)
- Feedback and suggestions for stronger passwords
- Custom wordlist creation with:
  - Name/DOB/Pet combinations
  - Years appended
  - Leetspeak variants (e.g., "password" → "p@$$w0rd")

---

## ⚙️ Setup Instructions

### 1. Clone or Download
```bash
git clone https://github.com/your-username/password-strength-analyzer.git
cd password-strength-analyzer
```

### 2. Install Requirements
```bash
pip install -r requirements.txt
```

---

## 🧪 How to Use

### Run the main program
```bash
python main.py
```

You’ll be prompted to choose:

**Option 1: Password Strength Analyzer**
- Enter a password to get its score and crack time.

**Option 2: Custom Wordlist Generator**
- Enter your name, DOB, and pet name.
- Generates a wordlist saved as `custom_wordlist.txt`.

---

## 📁 Output

- Wordlist saved in the same folder as `custom_wordlist.txt`
- Password analysis shown in terminal output

---

## 🛠 Tools & Libraries Used

- Python
- [`zxcvbn`](https://github.com/dropbox/zxcvbn) – for password strength analysis

---

## 📄 License

This project is intended for educational and ethical use only.

---

> 🚨 Always practice responsible cybersecurity. Do not use this tool for malicious purposes.
